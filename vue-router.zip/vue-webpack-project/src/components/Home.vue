
<template>
 <div > <vlink href="/about">about</vlink>
     <vlink href="/">home</vlink>
     <p>home</p>
 </div>
</template>




<script>
import Vlink from './Vlink.vue'
export default {
  name: 'home',
  data () {
    return {
      msg: 0
    }
  },
  components:{Vlink},
  methods:{
    inc: function(){
      this.msg++;
    }
  }
}
</script>