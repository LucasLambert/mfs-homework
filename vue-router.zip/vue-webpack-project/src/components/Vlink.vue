<template>

<a @click="onClick" :href="href">
    <slot></slot>
</a>


</template>

<script>
export default {
  name: 'vlink',
    data () {
    return {
      count: 0
    }
  },
  props:{
     href:{
         type:String,
         required:true,
         }
  },
  methods:{
    onClick:function(e){
        e.preventDefault()
        let path=this.href
        this.$root.currentRoute=path
        window.history.pushState(null,null,path)
    }
      }
  }

</script>
<style scoped>
a{
    cursor: pointer;
}

</style>
