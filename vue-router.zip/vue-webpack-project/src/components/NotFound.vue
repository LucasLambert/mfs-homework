
<template>
 <div >notfound
 </div>
</template>




<script>
import Vlink from './Vlink.vue'
export default {
  name: 'Not',
  data () {
    return {
      msg: 0
    }
  },
  components:{Vlink},
  methods:{
    inc: function(){
      this.msg++;
    }
  }
}
</script>