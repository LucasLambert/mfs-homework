
<template>
  <div class="mainpage">
    <div class='article'>
    <div v-for='i in articles' :key="i">
      <marticle :article=i></marticle>
    </div>
    </div>
    <larticle class='la' :Larticle=Larticles :Filedate=Filedate :tag=Ltag></larticle>
  </div>
</template>

<script>
/* eslint-disable */
import Larticle from '../components/Larticle'
import Marticle from '../components/Marticle'

export default {
  name: 'Home',
  data () {
    return {
      articles:[
        {
          title:'自动化前端测试',
          tag:'前端',
          date:"2017/6/17",
          clickTimes:"221",
          content:"首先本文不会探讨单元测试方向，因为单测已经有完善的工具体系。但前端开发中，除了一些框架和库，愿意去写单测的少之又少。另外单测维护成本较高，而且也没法满足前端测试的所有需求。 用户可以基于 tag 来快速筛选感兴趣的文章，文章也可以依照 而且人工设置难免不规范和不完全。",

        },
         {
          title:'自动化前端测试',
          tag:'前端',
          date:"2017/6/17",
          clickTimes:"222",
          content:"首先本文不会探讨单元测试方向，因为单测已经有完善的工具体系。但前端开发中，除了一些框架和库，愿意去写单测的少之又少。另外单测维护成本较高，而且也没法满足前端测试的所有需求。 用户可以基于 tag 来快速筛选感兴趣的文章，文章也可以依照 而且人工设置难免不规范和不完全。",
        },
         {
          title:'自动化前端测试',
          tag:'前端',
          date:"2017/6/17",
          clickTimes:"222",
          content:"首先本文不会探讨单元测试方向，因为单测已经有完善的工具体系。但前端开发中，除了一些框架和库，愿意去写单测的少之又少。另外单测维护成本较高，而且也没法满足前端测试的所有需求。 用户可以基于 tag 来快速筛选感兴趣的文章，文章也可以依照 而且人工设置难免不规范和不完全。",
          
        },
      ],
      Larticles:[
        {title:'前端文章1'},
        {title:'前端文章2'},
        {title:'前端文章3'},
      
      ],
      Filedate:[
        {id :1,
        date:"2017/7/18"
        },
         {id :2,
        date:"2018/7/18"
        },
         {id :3,
        date:"2019/7/18"
        }],
        Ltag:[
          {
            name:'前端'
          },
          {
            name:'css'
          },
          {
            name:'后台'
          },
        
      ]
    }
  },
  components:{Larticle,Marticle}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mainpage{
  display: flex;
}
.article{
  width: 60%;
}
.la{
  width: 40%
}
</style>
