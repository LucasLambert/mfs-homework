<template>
<div class="about">
  <h1>关于我们</h1>
  <img src="../assets/images/me.jpg" alt="">
  <div class="content">Responsive web design offers us a way forward, finally allowing us to design for the ebb and flow of things. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly.


Responsive web design offers us a way forward, finally allowing us to design for the ebb and flow of things. There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don’t look even slightly.
</div>
</div>
</template>

<script>
/* eslint-disable */
export default {
  name: "about",
  data() {
    return {};
  }
};

</script>
<style scoped>
.about{
  text-align: center
}
img{
  margin-top:30px
}
.content{
  text-align: left;
  line-height: 1.5;
  font-weight: bold;
  margin-top: 30px;
  font-size: 25px;
}

</style>
