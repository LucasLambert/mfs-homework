
<template>
  <div class="mainpage">
    <div class='article'>
      <detail :detail=articles></detail>
    </div>
  <larticle class='la' :Larticle=Larticles :Filedate=Filedate :tag=Ltag></larticle>
  </div>
</template>

<script>
/* eslint-disable */
import Larticle from '../components/Larticle'
import Marticle from '../components/Marticle'
import Detail from '../components/Detail'

export default {
  name: 'article',
  data () {
    return {
       articles:
        {
          title:'自动化前端测试',
          tag:'前端',
          date:"2017/6/17",
          clickTimes:"221",
          content:"随着屏幕的大小变换，内容区域的元素会匹配屏幕重新布局，就是我们说的自适应效果。我们在.col列中追加class类就可以实现自适应效果。如超小屏幕(xs)、超大屏幕(xl)。栅格系统首先会匹配移动手机版小屏幕，所以每个.col都需要一个class如：.xs-*，这样的话如果大屏幕的类没有设置，它就会使用这个.xs-*。 本文不会探讨单元测试方向，因为单测已经有完善的工具体系。但前端开发中，除了一些框架和库，愿意去写单测的少之又少。另外单测维护成本较高，而且也没法满足前端测试的所有需求。用户可以基于首先本文不会探讨单元测试方向，因为单测已经有完善的工具体系。但前端开发中，除了一些框架和库，愿意去写单测的少之又少。另外单测维护成本较高，而且也没法满足前端测试的所有需求。用户可以基于 tag 来快速筛选感兴趣的文章，文章也可以依照 而且人工设置难免不规范和不完全。",
        },
           Larticles:[
        {title:'前端文章1'},
        {title:'前端文章2'},
        {title:'前端文章3'},
      
      ],
      Filedate:[
        {id :1,
        date:"2017/7/18"
        },
         {id :2,
        date:"2018/7/18"
        },
         {id :3,
        date:"2019/7/18"
        }],
        Ltag:[
          {
            name:'前端'
          },
          {
            name:'css'
          },
          {
            name:'后台'
          },
        
      ]
    }
  },
  components:{Larticle,Marticle,Detail}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.mainpage{
  display: flex;
}
.article{
  width: 60%;
}
.la{
  width: 40%
}
</style>
