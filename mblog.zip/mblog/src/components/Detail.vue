<template>
<div>
    <h2>{{detail.title}}</h2>
    <div class='head'><span>{{detail.tag}}</span><span>{{detail.date}}</span><span>{{detail.clickTimes}}</span></div>
    <div class='detail'>{{detail.content}}</div>
</div>
</template>

<script>
/* eslint-disable */
export default {
  name: "detail",
  props:{
      detail:{
          required:true,
          type:Object,
      }
  },
  data() {
    return {};
  }
};
</script>
 <style scoped>
 h2{
     text-align: center
 }
 span{
     font-size: 13px;
    font-weight: 150;
 }
 .head{
     margin-top:20px;
     text-align: center
 }
 span{
     margin-right: 5px;
 }
.detail{
    margin-top:40px;
    line-height: 1.5
}
.check{
    margin: 50px;
    text-align: center
}
</style>
