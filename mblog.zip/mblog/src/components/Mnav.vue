
<template>
    <nav class="nav">
        <h1>码蜂设博客</h1>
        <ul class='links'>
            <li><router-link to="/">主页</router-link></li>
            <li><router-link to="/about">关于</router-link></li>
        </ul>
    </nav>
</template>

<script>
/* eslint-disable */
export default {
  name: "mnav",
  data() {
    return {};
  }
};

</script>

<style scoped>
   h1{
      
       font-size: 40px;
       font-weight:400

   }
   .nav{
      
       display:flex;
       justify-content: space-between;
       align-items: center;
       padding-bottom: 10px;
       border-bottom:1px solid #eee
   }
   .links{
      display: flex;
      margin-right: 200px
    
   }
   .links li{
       font-size: 30px;
       margin: 0 20px;

   }
</style>

