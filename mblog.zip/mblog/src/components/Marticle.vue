<template>
<div>
    <h2>{{article.title}}</h2>
    <div class='head'><span>{{article.tag}}</span><span>{{article.date}}</span><span>{{article.clickTimes}}</span></div>
    <div class='abs'>{{article.content}}
    </div>
    <div class="check">
       <router-link to="/article">查看文章</router-link>
    </div>
</div>
</template>

<script>
/* eslint-disable */
export default {
  name: "marticle",
  props:{
      article:{
          required: true,
          type:Object

      }

  },

  data() {
    return {};
  }
};
</script>
 <style scoped>
 h2{
     text-align: center
 }
 span{
     font-size: 13px;
    font-weight: 150;
 }
 .head{
     margin-top:20px;
     text-align: center
 }
 span{
     margin-right: 5px;
 }
.abs{
    margin-top:40px;
    line-height: 1.5
}
.check{
    margin: 50px;
    text-align: center
}
</style>
