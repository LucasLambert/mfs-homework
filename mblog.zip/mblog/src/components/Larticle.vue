<template>
<div class='Lcontainer'>
    <div class="La">
    <h2>近期文章</h2>
       <ul>
        <li v-for="i in Larticle" :key="i"><router-link to='/'>{{i.title}}</router-link></li> 
        
      </ul>
     </div>
     <div class="guidang">
       <h2>文章归档</h2>
       <ul>
        <li v-for="k in Filedate" :key="k"><router-link to='/'>{{k.date}}</router-link></li> 
     
      </ul>
      </div>
      <div class="tag">
          <h2>标签</h2>
          <div class="labelContainer">
          <span class="label">前端</span>
          <span class="label">后台</span>
          <span class="label">后台</span>
          <span class="label">后台</span>
          <span class="label">后台</span>
          <span class="label">后台</span>
          <span class="label">后台</span>
          <span class="label">后台</span>

          </div>
         
      </div>
       
        
</div>
</template>

<script>
/* eslint-disable */
export default {
  name: "larticle",
  props:{
      Larticle:{
          required:true,
          type:Object,
      },
      Filedate:{
          required:true,
          type:Object,
      },
      tag:{
          required:true,
      }
  },
  data() {
    return {};
  }
};
</script>
 <style scoped>
 .Lcontainer{
     text-align: center
 }
 .labelContainer{
     display: flex;
    flex-wrap: wrap;
    justify-content: center;
    width: 30%;
    margin:0 auto;


 }
 h2,ul{
   text-align: center
 }

.label{
        padding: 1px 3px;
    border: 1px solid green;
    margin-right: 5px;
    font-size: 13px;
}


</style>
