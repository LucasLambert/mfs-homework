
<template>
  <div id="app">
    <div class='container'>
   <mnav></mnav>
   <router-view></router-view>
    </div>
  </div>
</template>

<script>
/* eslint-disable */
import Mnav from "./components/Mnav.vue";
export default {
  name: "App",
  components: {Mnav}
};
</script>
<style>
  ol,ul,body{
    margin: 0;
    padding: 0;
    
  }
  ol,ul{
    list-style: none;
  }
  .container{
    margin:0 auto;
   width: 75%
  }
  a{
        text-decoration: none;
        color: black
    
}
</style>
