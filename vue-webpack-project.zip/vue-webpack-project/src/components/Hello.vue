
<template>
 <div >{{msg}}
   <Btn @add='inc'></Btn>
   <Btn @add='inc'></Btn>
   <Btn @add='inc'></Btn>
 </div>
</template>




<script>
import Btn from './Btn.vue'
export default {
  name: 'Hello',
  data () {
    return {
      msg: 0
    }
  },
  components:{Btn},
  methods:{
    inc: function(){
      this.msg++;
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h1, h2 {
  font-weight: normal;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
