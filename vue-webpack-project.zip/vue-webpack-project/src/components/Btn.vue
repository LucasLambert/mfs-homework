<template>

 <button @click='add'>{{count}}</button>


</template>

<script>
export default {
  name: 'm',
    data () {
    return {
      count: 0
    }
  },
  methods:{
      add : function(){
          this.count++;
        this.$emit("add")
      }
  }
}
</script>
<style scoped>

</style>
