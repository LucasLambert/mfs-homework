const router = require('koa-router')()

router.get('/', async (ctx, next) => {
  await ctx.render('index', {
    title: 'Hello Koa 2!'
  })
})

router.post('/check', async (ctx, next) => {
  var a="lucasa"
  console.log(a)
  console.log(ctx.request.body)
  if(ctx.request.body.username==a)
  {ctx.body="重复";}
  else
  {ctx.body="成功";}
})

router.get('/json', async (ctx, next) => {
  ctx.body = {
    title: 'koa2 json'
  }
})

module.exports = router
